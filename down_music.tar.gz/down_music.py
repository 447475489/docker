# -*- coding: utf-8 -*-
"""
用途：
    遍历某目录的下级目录，并查找指定类型文件，复制到上层文件夹
"""
import os
import shutil


def get_dir(path, fileType):
    """
    :param path: 路径
    :param fileType: 需要复制的文件类型（.mkv或.avi等，前面需要加.）
    :return:null
    """
    # 查看当前目录文件列表（包含文件夹）
    allfilelist = os.listdir(path)

    for file in allfilelist:
	file.encode("raw_unicode_escape").decode("gbk")
        print(file, '\n','utf-8')
        filepath = os.path.join(path, file)
        # 判断是否是文件夹，如果是则继续遍历，否则打印信息
        if os.path.isdir(filepath):
            allfilelist2 = os.listdir(filepath)
            for file2 in allfilelist2:
                filepath3 = os.path.join(filepath, file2)
                # 判断文件是否以.avi结尾
                if filepath3.endswith(fileType):
                    print('找到文件：' + filepath3)
                    # 复制filepath3找到的文件到distPath目录
                    #shutil.copy(filepath3, distPath)
                    try:
                        shutil.copy(filepath3, distPath)
                    except shutil.SameFileError:
                        # code when Exception occur
                        pass
                    else:
                        # code if the exception does not occur
                        pass
                    finally:
                        # code which is executed always
                        shutil.copy(filepath3, distPath)
        else:
            print('不是文件夹，继续查找...')


if __name__ == '__main__':
    path = "/var/docker"
    # 复制到distPath目录，目录需先创建
    distPath = "/var/docker/music"
    get_dir(path, '.flac')

